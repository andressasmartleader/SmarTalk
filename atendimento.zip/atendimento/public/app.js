const $ = (sel) => document.querySelector(sel);
const app = $('.app');

const state = {
  channel: '',
  status: 'open',
  search: '',
  currentId: null,
  current: null,
  conversations: [],
  agent: localStorage.getItem('agentName') || '',
};

// ---------- utilidades ----------
const parseDate = (s) => new Date(s.includes('T') ? s : s.replace(' ', 'T') + 'Z');
const escapeHtml = (s = '') =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

function timeShort(s) {
  const d = parseDate(s);
  const today = new Date();
  return d.toDateString() === today.toDateString()
    ? d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

function waitingFor(s) {
  const min = Math.floor((Date.now() - parseDate(s).getTime()) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return `espera ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `espera ${h} h`;
  return `espera ${Math.floor(h / 24)} d`;
}

const contactLabel = (c) => c.contact_name || c.contact_phone || c.contact_email || 'Sem nome';
const channelName = (ch) => (ch === 'whatsapp' ? 'WhatsApp' : 'E-mail');

async function request(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Erro ${res.status}`);
  return data;
}

// ---------- lista ----------
async function loadConversations() {
  const params = new URLSearchParams();
  if (state.channel) params.set('channel', state.channel);
  if (state.status) params.set('status', state.status);
  if (state.search) params.set('search', state.search);
  state.conversations = await request(`/api/conversations?${params}`);
  renderList();
}

function renderList() {
  const list = $('#conversation-list');
  if (!state.conversations.length) {
    list.innerHTML = `<li class="empty-list">${
      state.search ? 'Nenhuma conversa encontrada para essa busca.' : 'Nenhuma conversa por aqui. Quando um cliente escrever, ela aparece nesta lista.'
    }</li>`;
    return;
  }
  list.innerHTML = state.conversations.map((c) => {
    const waiting = c.status === 'open' && c.unread > 0 && c.last_inbound_at;
    return `<li>
      <button class="conv" data-id="${c.id}" data-channel="${c.channel}" aria-current="${c.id === state.currentId}">
        <span class="conv-bar" aria-hidden="true"></span>
        <span class="conv-name">${escapeHtml(contactLabel(c))}</span>
        <span class="conv-side">
          <span class="conv-time">${timeShort(c.updated_at)}</span>
          ${waiting ? `<span class="waiting">${waitingFor(c.last_inbound_at)}</span>` : ''}
        </span>
        <span class="conv-preview">${c.channel === 'email' && c.subject ? `<strong>${escapeHtml(c.subject)}</strong> ` : ''}${escapeHtml(c.last_message || '')}</span>
        <span class="sr-only">${channelName(c.channel)}${c.unread ? `, ${c.unread} não lidas` : ''}</span>
      </button>
    </li>`;
  }).join('');
}

// ---------- conversa ----------
async function openConversation(id) {
  state.currentId = id;
  const [conv, messages] = await Promise.all([
    request(`/api/conversations/${id}`),
    request(`/api/conversations/${id}/messages`),
  ]);
  state.current = conv;
  renderThreadHeader();
  renderMessages(messages);
  $('#thread-empty').hidden = true;
  $('#thread-view').hidden = false;
  app.dataset.view = 'thread';
  const local = state.conversations.find((c) => c.id === id);
  if (local) local.unread = 0;
  renderList();
  $('#reply').focus();
}

function renderThreadHeader() {
  const c = state.current;
  const view = $('#thread-view');
  view.dataset.channel = c.channel;
  $('#thread-name').textContent = contactLabel(c);
  const address = c.channel === 'whatsapp' ? c.contact_phone : c.contact_email;
  const parts = [channelName(c.channel), address];
  if (c.subject) parts.push(c.subject);
  parts.push(c.assignee ? `com ${c.assignee}` : 'sem responsável');
  $('#thread-meta').textContent = parts.join(', ');
  $('#toggle-status').textContent = c.status === 'open' ? 'Encerrar' : 'Reabrir';
  $('#assign').hidden = Boolean(state.agent && c.assignee === state.agent);
  $('#window-warning').hidden = !(c.channel === 'whatsapp' && c.whatsapp_window_open === false && state.channels?.whatsapp);
  $('#send').textContent = c.channel === 'whatsapp' ? 'Enviar no WhatsApp' : 'Enviar e-mail';
  $('#send-error').hidden = true;
}

function messageHtml(m, isNew = false) {
  const statusLabel = {
    received: '', sent: 'enviada', delivered: 'entregue', read: 'lida',
    failed: 'falhou', simulated: 'simulada (canal sem credenciais)',
  }[m.status] ?? m.status;
  const who = m.direction === 'out' ? (m.author || 'Agente') : '';
  const meta = [who, timeShort(m.created_at), m.direction === 'out' ? statusLabel : ''].filter(Boolean).join(', ');
  return `<li class="msg ${m.direction}${isNew ? ' new' : ''}" data-external="${escapeHtml(m.external_id || '')}">
    <div class="msg-body">${escapeHtml(m.body)}</div>
    <div class="msg-meta">${escapeHtml(meta)}</div>
  </li>`;
}

function renderMessages(messages) {
  const list = $('#messages');
  let lastDay = '';
  list.innerHTML = messages.map((m) => {
    const day = parseDate(m.created_at).toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
    const divider = day !== lastDay ? `<li class="day-divider">${day}</li>` : '';
    lastDay = day;
    return divider + messageHtml(m);
  }).join('');
  list.scrollTop = list.scrollHeight;
}

function appendMessage(m) {
  const list = $('#messages');
  const nearBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 120;
  list.insertAdjacentHTML('beforeend', messageHtml(m, true));
  if (nearBottom || m.direction === 'out') list.scrollTop = list.scrollHeight;
}

// ---------- ações ----------
async function sendReply(e) {
  e.preventDefault();
  const textarea = $('#reply');
  const body = textarea.value.trim();
  if (!body || !state.currentId) return;
  const btn = $('#send');
  btn.disabled = true;
  $('#send-error').hidden = true;
  try {
    await request(`/api/conversations/${state.currentId}/messages`, {
      method: 'POST',
      body: { body, author: state.agent || 'Agente' },
    });
    textarea.value = '';
  } catch (err) {
    $('#send-error').textContent = err.message;
    $('#send-error').hidden = false;
  } finally {
    btn.disabled = false;
    textarea.focus();
  }
}

async function patchCurrent(changes) {
  const conv = await request(`/api/conversations/${state.currentId}`, { method: 'PATCH', body: changes });
  state.current = { ...state.current, ...conv };
  renderThreadHeader();
  loadConversations();
}

// ---------- tempo real ----------
const socket = io();
socket.on('message', ({ conversation, message }) => {
  if (conversation.id === state.currentId) {
    appendMessage(message);
    state.current = { ...state.current, ...conversation, whatsapp_window_open: message.direction === 'in' ? true : state.current.whatsapp_window_open };
    renderThreadHeader();
  }
  loadConversations();
});
socket.on('status', ({ externalId, status }) => {
  const el = document.querySelector(`.msg[data-external="${CSS.escape(externalId)}"] .msg-meta`);
  if (el) el.textContent = el.textContent.replace(/(enviada|entregue|lida|falhou)$/, { delivered: 'entregue', read: 'lida', failed: 'falhou', sent: 'enviada' }[status] || status);
});
socket.on('conversation', () => loadConversations());

// ---------- eventos da interface ----------
$('#conversation-list').addEventListener('click', (e) => {
  const btn = e.target.closest('.conv');
  if (btn) openConversation(Number(btn.dataset.id));
});

document.querySelectorAll('.segmented button').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.segmented button').forEach((b) => b.setAttribute('aria-checked', String(b === btn)));
    state.channel = btn.dataset.channel;
    loadConversations();
  });
});

let searchTimer;
$('#search').addEventListener('input', (e) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { state.search = e.target.value.trim(); loadConversations(); }, 250);
});
$('#status-filter').addEventListener('change', (e) => { state.status = e.target.value; loadConversations(); });

$('#composer').addEventListener('submit', sendReply);
$('#reply').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) $('#composer').requestSubmit();
});
$('#toggle-status').addEventListener('click', () =>
  patchCurrent({ status: state.current.status === 'open' ? 'closed' : 'open' }));
$('#assign').addEventListener('click', () => {
  if (!state.agent) { $('#agent-name').focus(); return; }
  patchCurrent({ assignee: state.agent });
});
$('#back').addEventListener('click', () => { app.dataset.view = 'list'; });

const agentInput = $('#agent-name');
agentInput.value = state.agent;
agentInput.addEventListener('change', () => {
  state.agent = agentInput.value.trim();
  localStorage.setItem('agentName', state.agent);
  if (state.current) renderThreadHeader();
});

// Simulador
const dialog = $('#simulator');
const simForm = $('#simulator-form');
$('#open-simulator').addEventListener('click', () => dialog.showModal());
$('#sim-cancel').addEventListener('click', () => dialog.close());
simForm.addEventListener('change', (e) => {
  if (e.target.name !== 'channel') return;
  simForm.querySelectorAll('[data-for]').forEach((el) => { el.hidden = el.dataset.for !== e.target.value; });
});
simForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(simForm));
  try {
    await request('/api/dev/simulate', { method: 'POST', body: data });
    dialog.close();
  } catch (err) {
    alert(err.message);
  }
});

// ---------- início ----------
async function init() {
  state.channels = await request('/api/channels');
  const s = state.channels;
  $('#channel-status').innerHTML = `
    <span class="${s.whatsapp ? 'on' : 'off'}">WhatsApp ${s.whatsapp ? 'conectado' : 'não conectado'}</span>
    <span class="${s.email ? 'on' : 'off'}">E-mail ${s.email ? 'conectado' : 'não conectado'}</span>`;
  $('#open-simulator').hidden = !s.simulator;
  await loadConversations();
  setInterval(renderList, 60000); // atualiza os tempos de espera
}
init();
