# Atendimento

Protótipo de plataforma de atendimento que reúne **WhatsApp** e **e-mail** numa única caixa de entrada para a equipe.

- Recebe mensagens do WhatsApp pela WhatsApp Cloud API (webhook oficial da Meta)
- Lê e-mails via IMAP e responde via SMTP, mantendo o mesmo fio (`In-Reply-To`/`References`)
- Inbox em tempo real (Socket.io), com filtros por canal, busca, situação e tempo de espera do cliente
- Assumir e encerrar conversas
- Respeita a janela de 24h do WhatsApp
- **Simulador**: em desenvolvimento, você testa tudo sem nenhuma credencial

## Rodando em 1 minuto

Requer Node.js 22.13 ou mais recente.

```bash
npm install
cp .env.example .env
npm run dev
```

Abra http://localhost:3000 e clique em **Simular mensagem de cliente**. Sem credenciais, as respostas aparecem como "simulada".

## Estrutura

```
src/
  server.js              Express + Socket.io
  db.js                  SQLite (node:sqlite, sem dependências nativas)
  conversations.js       núcleo: contatos, conversas, mensagens, eventos
  api.js                 API REST da inbox + simulador
  channels/whatsapp.js   webhook e envio pela Cloud API
  channels/email.js      leitura IMAP, envio SMTP, limpeza de citações
public/                  interface dos agentes (HTML, CSS e JS puros)
test/                    testes com node:test
```

Para adicionar um canal novo (Instagram, Telegram, chat do site), crie um arquivo em `src/channels/` que chame `receiveInbound()` ao receber e exponha uma função de envio usada em `api.js`.

## Conectando o WhatsApp

1. Em [developers.facebook.com](https://developers.facebook.com), crie um app do tipo **Empresa** e adicione o produto **WhatsApp**.
2. Em **WhatsApp → Configuração da API**, copie o token temporário e o **Phone number ID** para `WHATSAPP_TOKEN` e `WHATSAPP_PHONE_NUMBER_ID`. Cadastre seu celular como destinatário de teste.
3. Exponha o servidor com uma URL HTTPS pública (veja "Codespaces" abaixo, ou use `ngrok http 3000` ou `cloudflared tunnel --url http://localhost:3000`).
4. Em **WhatsApp → Configuração → Webhook**, informe:
   - URL de retorno: `https://SUA-URL/webhooks/whatsapp`
   - Token de verificação: o mesmo valor de `WHATSAPP_VERIFY_TOKEN`
5. Assine o campo **messages**.
6. Mande uma mensagem do seu celular para o número de teste. Ela aparece na inbox.

Para validar a assinatura dos webhooks, preencha `WHATSAPP_APP_SECRET` (Configurações do app → Básico → Chave secreta do app).

O token temporário expira em 24h. Para algo duradouro, crie um **usuário do sistema** no Gerenciador de Negócios e gere um token permanente.

## Conectando o e-mail

Com Gmail:

1. Ative a verificação em duas etapas na conta.
2. Gere uma **senha de app** em myaccount.google.com/apppasswords.
3. No `.env`:

```
IMAP_HOST=imap.gmail.com
SMTP_HOST=smtp.gmail.com
EMAIL_USER=suporte@suaempresa.com
EMAIL_PASSWORD=a-senha-de-app
```

A caixa é lida a cada `EMAIL_POLL_SECONDS` segundos. E-mails lidos são marcados como vistos.

## Usando no GitHub

**Criar o repositório**

```bash
git init
git add .
git commit -m "Protótipo de plataforma de atendimento"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/atendimento.git
git push -u origin main
```

O `.env` está no `.gitignore`. Nunca suba tokens ou senhas.

**Codespaces (desenvolver no navegador com URL pública para o webhook)**

1. No repositório: **Code → Codespaces → Create codespace on main**. O `.devcontainer` instala tudo sozinho.
2. Preencha o `.env` e rode `npm run dev`.
3. Na aba **Portas**, clique com o botão direito na porta 3000 → **Visibilidade da porta → Pública**.
4. Use essa URL no webhook da Meta.

**CI**

O workflow em `.github/workflows/ci.yml` roda verificação de sintaxe e testes a cada push e pull request.

**Publicar**

O GitHub Pages só hospeda sites estáticos, então o backend precisa de outro serviço. Render, Railway e Fly.io conectam direto ao repositório. Configure as variáveis do `.env` no painel do serviço e defina `NODE_ENV=production` (isso desliga o simulador). Use um disco persistente para a pasta `data/` ou migre para PostgreSQL.

## Limitações do protótipo e próximos passos

- **Sem login**: qualquer pessoa com a URL vê a inbox. Adicione autenticação antes de usar com clientes reais.
- **SQLite**: ótimo para protótipo. Para várias instâncias, migre para PostgreSQL.
- **Mídia**: imagens, áudios e documentos aparecem como `[imagem]`, `[áudio]` etc. O próximo passo é baixar a mídia pela Graph API e exibi-la.
- **Templates do WhatsApp**: a função `sendWhatsAppTemplate` existe, mas ainda não há interface para escolher um template fora da janela de 24h.
- **Outros recursos comuns**: respostas prontas, etiquetas, notas internas, transferência entre agentes, métricas de tempo de resposta, chatbot de triagem.

## Testes

```bash
npm test
```
