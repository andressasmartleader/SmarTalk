import express from 'express';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import { api } from './api.js';
import { events } from './conversations.js';
import { whatsappRouter, whatsappConfigured } from './channels/whatsapp.js';
import { startEmailPolling } from './channels/email.js';

const app = express();
const http = createServer(app);
const io = new Server(http);

// Guarda o corpo bruto para validar a assinatura do webhook da Meta.
app.use(express.json({
  limit: '2mb',
  verify: (req, _res, buf) => { req.rawBody = buf; },
}));

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use('/webhooks/whatsapp', whatsappRouter);
app.use('/api', api);
app.use(express.static('public'));

// Tempo real: toda novidade do núcleo vai para as telas abertas.
events.on('message', (payload) => io.emit('message', payload));
events.on('status', (payload) => io.emit('status', payload));
events.on('conversation', (payload) => io.emit('conversation', payload));

const PORT = Number(process.env.PORT || 3000);
http.listen(PORT, () => {
  console.log(`Inbox em http://localhost:${PORT}`);
  console.log(`Webhook do WhatsApp: <sua URL pública>/webhooks/whatsapp`);
  if (!whatsappConfigured()) console.log('[whatsapp] sem credenciais: respostas ficam como "simulado"');
  startEmailPolling();
});
