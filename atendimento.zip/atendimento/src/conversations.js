// Núcleo da plataforma: todo canal entra e sai por aqui, no mesmo formato.
import { EventEmitter } from 'node:events';
import { db } from './db.js';

// O servidor escuta estes eventos e repassa para a interface via Socket.io.
export const events = new EventEmitter();

const q = {
  contactByPhone: db.prepare('SELECT * FROM contacts WHERE phone = ?'),
  contactByEmail: db.prepare('SELECT * FROM contacts WHERE email = ?'),
  insertContact: db.prepare('INSERT INTO contacts (name, phone, email) VALUES (?, ?, ?)'),
  updateContactName: db.prepare('UPDATE contacts SET name = ? WHERE id = ? AND (name IS NULL OR name = \'\')'),
  contactById: db.prepare('SELECT * FROM contacts WHERE id = ?'),

  openConv: db.prepare(`SELECT * FROM conversations
    WHERE contact_id = ? AND channel = ? AND status = 'open'
    ORDER BY updated_at DESC LIMIT 1`),
  openConvBySubject: db.prepare(`SELECT * FROM conversations
    WHERE contact_id = ? AND channel = 'email' AND status = 'open' AND subject = ?
    ORDER BY updated_at DESC LIMIT 1`),
  convByMessageExternalId: db.prepare(`SELECT c.* FROM conversations c
    JOIN messages m ON m.conversation_id = c.id
    WHERE m.external_id = ? AND c.channel = ? LIMIT 1`),
  insertConv: db.prepare('INSERT INTO conversations (contact_id, channel, subject) VALUES (?, ?, ?)'),
  convById: db.prepare('SELECT * FROM conversations WHERE id = ?'),
  touchInbound: db.prepare(`UPDATE conversations
    SET status = 'open', unread = unread + 1, last_inbound_at = datetime('now'), updated_at = datetime('now')
    WHERE id = ?`),
  touchOutbound: db.prepare(`UPDATE conversations SET unread = 0, updated_at = datetime('now') WHERE id = ?`),

  msgByExternalId: db.prepare('SELECT id FROM messages WHERE external_id = ?'),
  insertMsg: db.prepare(`INSERT INTO messages (conversation_id, direction, body, external_id, status, author)
    VALUES (?, ?, ?, ?, ?, ?)`),
  msgById: db.prepare('SELECT * FROM messages WHERE id = ?'),
  msgsByConv: db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY id'),
  updateMsgStatus: db.prepare('UPDATE messages SET status = ? WHERE external_id = ?'),
  externalIdsByConv: db.prepare(`SELECT external_id FROM messages
    WHERE conversation_id = ? AND external_id IS NOT NULL ORDER BY id`),
};

function findOrCreateContact({ name, phone, email }) {
  let contact = phone ? q.contactByPhone.get(phone) : q.contactByEmail.get(email);
  if (!contact) {
    const { lastInsertRowid } = q.insertContact.run(name || null, phone || null, email || null);
    contact = q.contactById.get(lastInsertRowid);
  } else if (name) {
    q.updateContactName.run(name, contact.id);
  }
  return contact;
}

/**
 * Registra uma mensagem recebida de qualquer canal.
 * @param {object} p
 * @param {'whatsapp'|'email'} p.channel
 * @param {{name?: string, phone?: string, email?: string}} p.from
 * @param {string} p.body
 * @param {string} [p.externalId]  id da mensagem no canal (wamid do WhatsApp, Message-ID do e-mail)
 * @param {string} [p.subject]     assunto (e-mail)
 * @param {string[]} [p.references] ids de mensagens anteriores do mesmo fio (e-mail)
 * @returns a mensagem salva, ou null se já tinha sido recebida (webhooks podem repetir)
 */
export function receiveInbound({ channel, from, body, externalId, subject, references = [] }) {
  if (externalId && q.msgByExternalId.get(externalId)) return null;

  const contact = findOrCreateContact(from);

  // E-mail: tenta achar o fio pela cadeia In-Reply-To/References.
  let conversation = null;
  for (const ref of references) {
    conversation = q.convByMessageExternalId.get(ref, channel);
    if (conversation) break;
  }
  // E-mail sem cabeçalhos de fio: reaproveita conversa aberta do contato com o mesmo assunto.
  if (!conversation && channel === 'email' && subject) {
    conversation = q.openConvBySubject.get(contact.id, subject);
  }
  // WhatsApp (ou e-mail sem assunto): reaproveita a conversa aberta do contato.
  if (!conversation && (channel === 'whatsapp' || !subject)) {
    conversation = q.openConv.get(contact.id, channel);
  }
  if (!conversation) {
    const { lastInsertRowid } = q.insertConv.run(contact.id, channel, subject || null);
    conversation = q.convById.get(lastInsertRowid);
  }

  const { lastInsertRowid } = q.insertMsg.run(conversation.id, 'in', body, externalId || null, 'received', null);
  q.touchInbound.run(conversation.id);

  const message = q.msgById.get(lastInsertRowid);
  events.emit('message', { conversation: getConversation(conversation.id), message });
  return message;
}

/** Registra uma mensagem enviada pelo agente. */
export function recordOutbound({ conversationId, body, author, externalId, status = 'sent' }) {
  const { lastInsertRowid } = q.insertMsg.run(conversationId, 'out', body, externalId || null, status, author || null);
  q.touchOutbound.run(conversationId);
  const message = q.msgById.get(lastInsertRowid);
  events.emit('message', { conversation: getConversation(conversationId), message });
  return message;
}

/** Atualiza status de entrega (ex.: 'delivered', 'read') vindo do webhook do WhatsApp. */
export function updateDeliveryStatus(externalId, status) {
  const { changes } = q.updateMsgStatus.run(status, externalId);
  if (changes) events.emit('status', { externalId, status });
}

export function getConversation(id) {
  const conv = db.prepare(`
    SELECT c.*, ct.name AS contact_name, ct.phone AS contact_phone, ct.email AS contact_email,
      (SELECT body FROM messages m WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) AS last_message
    FROM conversations c JOIN contacts ct ON ct.id = c.contact_id
    WHERE c.id = ?`).get(id);
  return conv || null;
}

export function listConversations({ status, channel, search } = {}) {
  const where = [];
  const params = [];
  if (status) { where.push('c.status = ?'); params.push(status); }
  if (channel) { where.push('c.channel = ?'); params.push(channel); }
  if (search) {
    where.push('(ct.name LIKE ? OR ct.phone LIKE ? OR ct.email LIKE ? OR c.subject LIKE ?)');
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }
  return db.prepare(`
    SELECT c.*, ct.name AS contact_name, ct.phone AS contact_phone, ct.email AS contact_email,
      (SELECT body FROM messages m WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) AS last_message
    FROM conversations c JOIN contacts ct ON ct.id = c.contact_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY c.updated_at DESC, c.id DESC
    LIMIT 200`).all(...params);
}

export function getMessages(conversationId) {
  db.prepare('UPDATE conversations SET unread = 0 WHERE id = ?').run(conversationId);
  return q.msgsByConv.all(conversationId);
}

export function getThreadReferences(conversationId) {
  return q.externalIdsByConv.all(conversationId).map((r) => r.external_id);
}

export function updateConversation(id, { status, assignee }) {
  if (status) db.prepare('UPDATE conversations SET status = ?, updated_at = datetime(\'now\') WHERE id = ?').run(status, id);
  if (assignee !== undefined) db.prepare('UPDATE conversations SET assignee = ? WHERE id = ?').run(assignee || null, id);
  const conversation = getConversation(id);
  events.emit('conversation', conversation);
  return conversation;
}

/** Janela de 24h do WhatsApp: fora dela, só templates aprovados. */
export function isWhatsAppWindowOpen(conversation) {
  if (!conversation.last_inbound_at) return false;
  const last = new Date(conversation.last_inbound_at.replace(' ', 'T') + 'Z');
  return Date.now() - last.getTime() < 24 * 60 * 60 * 1000;
}
