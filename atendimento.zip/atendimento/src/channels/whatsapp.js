// Canal WhatsApp via WhatsApp Cloud API (Meta).
// Docs: https://developers.facebook.com/docs/whatsapp/cloud-api
import { Router } from 'express';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { receiveInbound, updateDeliveryStatus } from '../conversations.js';

const env = () => ({
  token: process.env.WHATSAPP_TOKEN,
  phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID,
  verifyToken: process.env.WHATSAPP_VERIFY_TOKEN,
  appSecret: process.env.WHATSAPP_APP_SECRET,
  version: process.env.WHATSAPP_API_VERSION || 'v21.0',
});

export const whatsappConfigured = () => Boolean(env().token && env().phoneNumberId);

export const whatsappRouter = Router();

// 1) Verificação: a Meta chama este GET quando você salva a URL do webhook no painel.
whatsappRouter.get('/', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token && token === env().verifyToken) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// Confere a assinatura X-Hub-Signature-256 (opcional, ativa se WHATSAPP_APP_SECRET existir).
function validSignature(req) {
  const secret = env().appSecret;
  if (!secret) return true;
  const header = req.get('x-hub-signature-256') || '';
  const expected = 'sha256=' + createHmac('sha256', secret).update(req.rawBody || '').digest('hex');
  const a = Buffer.from(header);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

// 2) Recebimento: mensagens novas e status de entrega chegam neste POST.
whatsappRouter.post('/', (req, res) => {
  if (!validSignature(req)) return res.sendStatus(401);
  res.sendStatus(200); // responda rápido; a Meta reenvia se demorar

  try {
    for (const entry of req.body?.entry ?? []) {
      for (const change of entry.changes ?? []) {
        handleChange(change.value ?? {});
      }
    }
  } catch (err) {
    console.error('[whatsapp] erro ao processar webhook:', err);
  }
});

function handleChange(value) {
  const names = Object.fromEntries((value.contacts ?? []).map((c) => [c.wa_id, c.profile?.name]));

  for (const msg of value.messages ?? []) {
    receiveInbound({
      channel: 'whatsapp',
      from: { phone: msg.from, name: names[msg.from] },
      body: extractText(msg),
      externalId: msg.id,
    });
  }

  for (const st of value.statuses ?? []) {
    updateDeliveryStatus(st.id, st.status); // sent | delivered | read | failed
  }
}

function extractText(msg) {
  switch (msg.type) {
    case 'text': return msg.text.body;
    case 'button': return msg.button.text;
    case 'interactive': return msg.interactive.button_reply?.title || msg.interactive.list_reply?.title || '[interação]';
    case 'image': return msg.image.caption ? `[imagem] ${msg.image.caption}` : '[imagem]';
    case 'audio': return '[áudio]';
    case 'video': return '[vídeo]';
    case 'document': return `[documento] ${msg.document.filename ?? ''}`.trim();
    case 'location': return `[localização] ${msg.location.latitude}, ${msg.location.longitude}`;
    case 'sticker': return '[figurinha]';
    default: return `[${msg.type}]`;
  }
}

/** Envia texto livre (só funciona dentro da janela de 24h). Retorna o wamid. */
export async function sendWhatsAppText(to, body) {
  const { token, phoneNumberId, version } = env();
  const res = await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to,
      type: 'text',
      text: { preview_url: false, body },
    }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data?.error?.message || `WhatsApp API respondeu ${res.status}`);
  }
  return data.messages?.[0]?.id;
}

/** Envia um template aprovado (necessário fora da janela de 24h). */
export async function sendWhatsAppTemplate(to, name, language = 'pt_BR', components = []) {
  const { token, phoneNumberId, version } = env();
  const res = await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      to,
      type: 'template',
      template: { name, language: { code: language }, components },
    }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `WhatsApp API respondeu ${res.status}`);
  return data.messages?.[0]?.id;
}
