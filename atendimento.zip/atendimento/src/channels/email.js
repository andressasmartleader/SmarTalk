// Canal de e-mail: lê a caixa de entrada via IMAP e responde via SMTP.
// Alternativa mais robusta: webhooks de inbound parse (SendGrid, Mailgun, Postmark).
import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import nodemailer from 'nodemailer';
import { randomUUID } from 'node:crypto';
import { receiveInbound } from '../conversations.js';

const env = () => ({
  imapHost: process.env.IMAP_HOST,
  imapPort: Number(process.env.IMAP_PORT || 993),
  smtpHost: process.env.SMTP_HOST,
  smtpPort: Number(process.env.SMTP_PORT || 465),
  user: process.env.EMAIL_USER,
  pass: process.env.EMAIL_PASSWORD,
  fromName: process.env.EMAIL_FROM_NAME || 'Atendimento',
  pollSeconds: Number(process.env.EMAIL_POLL_SECONDS || 30),
});

export const emailConfigured = () => Boolean(env().imapHost && env().user && env().pass);

let transporter;
function getTransporter() {
  const e = env();
  transporter ??= nodemailer.createTransport({
    host: e.smtpHost,
    port: e.smtpPort,
    secure: e.smtpPort === 465,
    auth: { user: e.user, pass: e.pass },
  });
  return transporter;
}

// Remove o histórico citado ("Em ... escreveu:", linhas com ">") para mostrar só a resposta nova.
export function stripQuotedReply(text = '') {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const cut = lines.findIndex((l) =>
    /^\s*>/.test(l) ||
    /^(Em|On)\s.+(escreveu|wrote):\s*$/i.test(l.trim()) ||
    /^-{2,}\s*(Mensagem original|Original Message)/i.test(l.trim()),
  );
  const kept = cut === -1 ? lines : lines.slice(0, cut);
  return kept.join('\n').trim() || text.trim();
}

async function pollOnce() {
  const e = env();
  const client = new ImapFlow({
    host: e.imapHost,
    port: e.imapPort,
    secure: true,
    auth: { user: e.user, pass: e.pass },
    logger: false,
  });

  await client.connect();
  const lock = await client.getMailboxLock('INBOX');
  try {
    const uids = await client.search({ seen: false }, { uid: true });
    for (const uid of uids || []) {
      const { source } = await client.fetchOne(uid, { source: true }, { uid: true });
      const mail = await simpleParser(source);
      const from = mail.from?.value?.[0];
      if (!from?.address || from.address.toLowerCase() === e.user.toLowerCase()) continue;

      const references = [
        ...(Array.isArray(mail.references) ? mail.references : mail.references ? [mail.references] : []),
        ...(mail.inReplyTo ? [mail.inReplyTo] : []),
      ].reverse(); // o mais recente primeiro

      receiveInbound({
        channel: 'email',
        from: { email: from.address.toLowerCase(), name: from.name },
        body: stripQuotedReply(mail.text || '(sem conteúdo em texto)'),
        externalId: mail.messageId,
        subject: (mail.subject || '').replace(/^(re|fw|fwd|enc|res):\s*/i, '') || '(sem assunto)',
        references,
      });

      await client.messageFlagsAdd(uid, ['\\Seen'], { uid: true });
    }
  } finally {
    lock.release();
    await client.logout();
  }
}

export function startEmailPolling() {
  if (!emailConfigured()) {
    console.log('[email] canal desativado (IMAP_HOST/EMAIL_USER/EMAIL_PASSWORD não definidos)');
    return;
  }
  const { pollSeconds } = env();
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await pollOnce();
    } catch (err) {
      console.error('[email] erro ao ler caixa:', err.message);
    } finally {
      running = false;
    }
  };
  tick();
  setInterval(tick, pollSeconds * 1000);
  console.log(`[email] lendo a caixa a cada ${pollSeconds}s`);
}

/** Responde no mesmo fio. Retorna o Message-ID gerado. */
export async function sendEmailReply({ to, subject, body, references = [] }) {
  const e = env();
  const domain = e.user.split('@')[1] || 'localhost';
  const messageId = `<${randomUUID()}@${domain}>`;
  const last = references[references.length - 1];

  await getTransporter().sendMail({
    from: { name: e.fromName, address: e.user },
    to,
    subject: subject ? `Re: ${subject}` : 'Re: seu contato',
    text: body,
    messageId,
    ...(last ? { inReplyTo: last, references } : {}),
  });
  return messageId;
}
