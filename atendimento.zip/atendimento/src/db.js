// Banco SQLite usando o módulo nativo do Node (node:sqlite), sem dependências nativas.
// Para produção, troque por PostgreSQL (ex.: Prisma ou pg) mantendo as mesmas funções.
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';

const DB_PATH = process.env.DB_PATH || 'data/atendimento.db';
if (DB_PATH !== ':memory:') mkdirSync('data', { recursive: true });

export const db = new DatabaseSync(DB_PATH);

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS contacts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT,
    phone       TEXT UNIQUE,
    email       TEXT UNIQUE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_id      INTEGER NOT NULL REFERENCES contacts(id),
    channel         TEXT NOT NULL CHECK (channel IN ('whatsapp', 'email')),
    status          TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
    subject         TEXT,
    assignee        TEXT,
    unread          INTEGER NOT NULL DEFAULT 0,
    last_inbound_at TEXT,
    updated_at      TEXT NOT NULL DEFAULT (datetime('now')),
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id),
    direction       TEXT NOT NULL CHECK (direction IN ('in', 'out')),
    body            TEXT NOT NULL,
    external_id     TEXT,
    status          TEXT NOT NULL DEFAULT 'received',
    author          TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_external ON messages(external_id) WHERE external_id IS NOT NULL;
  CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, id);
  CREATE INDEX IF NOT EXISTS idx_conv_updated ON conversations(updated_at DESC);
`);
