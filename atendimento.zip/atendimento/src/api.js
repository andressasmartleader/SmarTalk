// API REST da inbox. A interface dos agentes usa estas rotas.
import { Router } from 'express';
import {
  listConversations, getConversation, getMessages, updateConversation,
  recordOutbound, receiveInbound, getThreadReferences, isWhatsAppWindowOpen,
} from './conversations.js';
import { sendWhatsAppText, whatsappConfigured } from './channels/whatsapp.js';
import { sendEmailReply, emailConfigured } from './channels/email.js';

export const api = Router();
const isDev = () => process.env.NODE_ENV !== 'production';

api.get('/channels', (_req, res) => {
  res.json({
    whatsapp: whatsappConfigured(),
    email: emailConfigured(),
    simulator: isDev(),
  });
});

api.get('/conversations', (req, res) => {
  const { status, channel, search } = req.query;
  res.json(listConversations({ status, channel, search }));
});

api.get('/conversations/:id', (req, res) => {
  const conv = getConversation(Number(req.params.id));
  if (!conv) return res.status(404).json({ error: 'Conversa não encontrada' });
  res.json({ ...conv, whatsapp_window_open: conv.channel === 'whatsapp' ? isWhatsAppWindowOpen(conv) : null });
});

api.get('/conversations/:id/messages', (req, res) => {
  res.json(getMessages(Number(req.params.id)));
});

api.patch('/conversations/:id', (req, res) => {
  const { status, assignee } = req.body ?? {};
  if (status && !['open', 'closed'].includes(status)) {
    return res.status(400).json({ error: 'status deve ser "open" ou "closed"' });
  }
  const conv = updateConversation(Number(req.params.id), { status, assignee });
  if (!conv) return res.status(404).json({ error: 'Conversa não encontrada' });
  res.json(conv);
});

// Envia resposta pelo canal da conversa.
api.post('/conversations/:id/messages', async (req, res) => {
  const conv = getConversation(Number(req.params.id));
  if (!conv) return res.status(404).json({ error: 'Conversa não encontrada' });

  const body = String(req.body?.body ?? '').trim();
  const author = req.body?.author || 'Agente';
  if (!body) return res.status(400).json({ error: 'Escreva uma mensagem antes de enviar' });

  try {
    let externalId = null;
    let status = 'sent';

    if (conv.channel === 'whatsapp') {
      if (!whatsappConfigured()) {
        if (!isDev()) throw new Error('WhatsApp não configurado. Preencha WHATSAPP_TOKEN e WHATSAPP_PHONE_NUMBER_ID.');
        status = 'simulated';
      } else {
        if (!isWhatsAppWindowOpen(conv)) {
          return res.status(422).json({
            error: 'Passaram mais de 24h desde a última mensagem do cliente. No WhatsApp, só é possível enviar um template aprovado.',
          });
        }
        externalId = await sendWhatsAppText(conv.contact_phone, body);
      }
    } else {
      if (!emailConfigured()) {
        if (!isDev()) throw new Error('E-mail não configurado. Preencha as variáveis IMAP/SMTP.');
        status = 'simulated';
      } else {
        externalId = await sendEmailReply({
          to: conv.contact_email,
          subject: conv.subject,
          body,
          references: getThreadReferences(conv.id),
        });
      }
    }

    const message = recordOutbound({ conversationId: conv.id, body, author, externalId, status });
    res.status(201).json(message);
  } catch (err) {
    console.error(`[${conv.channel}] falha ao enviar:`, err.message);
    res.status(502).json({ error: `Não foi possível enviar: ${err.message}` });
  }
});

// Simulador: cria mensagens recebidas sem precisar de Meta ou caixa de e-mail.
api.post('/dev/simulate', (req, res) => {
  if (!isDev()) return res.sendStatus(404);
  const { channel = 'whatsapp', name, phone, email, subject, body } = req.body ?? {};
  if (!body) return res.status(400).json({ error: 'Informe o texto da mensagem' });

  const message = receiveInbound({
    channel,
    from: channel === 'whatsapp'
      ? { phone: phone || '5511999990000', name: name || 'Cliente de teste' }
      : { email: (email || 'cliente@exemplo.com').toLowerCase(), name: name || 'Cliente de teste' },
    body,
    subject: channel === 'email' ? subject || 'Dúvida sobre meu pedido' : undefined,
    externalId: `sim-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
  });
  res.status(201).json(message);
});
