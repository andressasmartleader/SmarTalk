import { test } from 'node:test';
import assert from 'node:assert/strict';

process.env.DB_PATH = ':memory:';
const { receiveInbound, recordOutbound, listConversations, getMessages, updateConversation, isWhatsAppWindowOpen, getConversation } =
  await import('../src/conversations.js');
const { stripQuotedReply } = await import('../src/channels/email.js');

test('mensagens do mesmo número no WhatsApp ficam na mesma conversa', () => {
  const a = receiveInbound({ channel: 'whatsapp', from: { phone: '5511900000001', name: 'Ana' }, body: 'oi', externalId: 'wamid.1' });
  const b = receiveInbound({ channel: 'whatsapp', from: { phone: '5511900000001' }, body: 'tudo bem?', externalId: 'wamid.2' });
  assert.equal(a.conversation_id, b.conversation_id);
  assert.equal(getMessages(a.conversation_id).length, 2);
});

test('webhook repetido não duplica mensagem', () => {
  receiveInbound({ channel: 'whatsapp', from: { phone: '5511900000002' }, body: 'x', externalId: 'wamid.dup' });
  const again = receiveInbound({ channel: 'whatsapp', from: { phone: '5511900000002' }, body: 'x', externalId: 'wamid.dup' });
  assert.equal(again, null);
});

test('resposta de e-mail entra no fio certo pelos cabeçalhos', () => {
  const first = receiveInbound({
    channel: 'email', from: { email: 'bia@exemplo.com' }, body: 'Pedido atrasado',
    subject: 'Pedido 10', externalId: '<m1@exemplo.com>',
  });
  recordOutbound({ conversationId: first.conversation_id, body: 'Vamos verificar', externalId: '<r1@loja.com>' });
  const reply = receiveInbound({
    channel: 'email', from: { email: 'bia@exemplo.com' }, body: 'Obrigada',
    subject: 'Outro assunto qualquer', externalId: '<m2@exemplo.com>', references: ['<r1@loja.com>'],
  });
  assert.equal(reply.conversation_id, first.conversation_id);
});

test('e-mail com assunto novo abre outra conversa', () => {
  const a = receiveInbound({ channel: 'email', from: { email: 'caio@exemplo.com' }, body: 'a', subject: 'Troca', externalId: '<c1@x>' });
  const b = receiveInbound({ channel: 'email', from: { email: 'caio@exemplo.com' }, body: 'b', subject: 'Nota fiscal', externalId: '<c2@x>' });
  assert.notEqual(a.conversation_id, b.conversation_id);
});

test('encerrar e filtrar conversas', () => {
  const m = receiveInbound({ channel: 'whatsapp', from: { phone: '5511900000003' }, body: 'fim', externalId: 'wamid.3' });
  updateConversation(m.conversation_id, { status: 'closed' });
  assert.ok(listConversations({ status: 'closed' }).some((c) => c.id === m.conversation_id));
  assert.ok(!listConversations({ status: 'open' }).some((c) => c.id === m.conversation_id));
});

test('janela de 24h do WhatsApp', () => {
  const m = receiveInbound({ channel: 'whatsapp', from: { phone: '5511900000004' }, body: 'oi', externalId: 'wamid.4' });
  assert.equal(isWhatsAppWindowOpen(getConversation(m.conversation_id)), true);
  assert.equal(isWhatsAppWindowOpen({ last_inbound_at: '2020-01-01 00:00:00' }), false);
});

test('remove histórico citado do e-mail', () => {
  const text = 'Pode trocar pelo tamanho M?\n\nEm seg., 3 de mar. de 2026 às 10:00, Loja <x@y.com> escreveu:\n> Olá!';
  assert.equal(stripQuotedReply(text), 'Pode trocar pelo tamanho M?');
});
